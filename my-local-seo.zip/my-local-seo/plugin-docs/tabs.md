# Tabs and Subtabs

This section documents each tab and subtab in the plugin admin area.

## Main Tabs:

## Api Integration
**File:** `api-integration.php`


---

## Site Builder
**File:** `site-builder.php`


---

## Ai
**File:** `tab-ai.php`


---

## Bulk
**File:** `tab-bulk.php`


---

## Cpt
**File:** `tab-cpt.php`


---

## Dashboard
**File:** `tab-dashboard.php`


---

## Meta
**File:** `tab-meta.php`


---

## Migration
**File:** `tab-migration.php`


---

## Schema
**File:** `tab-schema.php`


---

## Shortcodes
**File:** `tab-shortcodes.php`


---

## Yt Video Blog
**File:** `yt-video-blog.php`


---
